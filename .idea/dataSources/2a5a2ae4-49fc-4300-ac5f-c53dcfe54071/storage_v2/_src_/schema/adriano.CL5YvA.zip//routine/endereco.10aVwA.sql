create
    definer = root@localhost procedure endereco(IN cpf_responsavel varchar(32))
SELECT tb_responsaveis.id , tb_alunos.id
FROM tb_responsaveis
INNER JOIN tb_alunos ON tb_responsaveis.id = tb_alunos.responsavel_id WHERE tb_responsaveis.cpf = cpf_responsavel;

