create
    definer = root@localhost procedure aluno_responsavel(IN cpf_responsavel varchar(11))
SELECT id FROM tb_receivers WHERE cpf = cpf_responsavel;

